from django.urls import path
from . import views

urlpatterns = [
    path('', views.signin, name='signin'),
    path('login/', views.login, name='login'),
    path('login/add-disease/', views.dashboard, name='add-disease'),
    path('login/add-disease/disease_info',views.disease_info),
    path('disease-list/', views.disease_list, name='disease_list'),
    path('index/', views.index, name='index'),
    path('users/',views.user_list, name='user_list'),
path('disease_info/', views.disease_info, name='disease_info'),
]
