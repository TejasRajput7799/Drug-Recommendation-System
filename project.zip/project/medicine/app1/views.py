from django.shortcuts import render
from django.http import HttpResponse
import mysql.connector
# from psutil import users
# from urllib3 import request


# def signin(request):
#     return render(request, 'signin.html')
#
#
# def login(request):
#     email = request.GET.get("email")
#     upass = request.GET.get("upass")
#
#     try:
#         # Connect to MySQL
#         mydb = mysql.connector.connect(
#             host="127.0.0.1",
#             user="root",
#             password="",
#             database="projects"
#         )
#         cursor = mydb.cursor(buffered=True)
#
#         # Query to check credentials
#         query = "SELECT * FROM usermast WHERE email = %s AND upass = %s"
#         values = (email, upass)
#         cursor.execute(query, values)
#
#         # Fetch the result
#         user = cursor.fetchone()
#
#         # Close the cursor and connection
#         cursor.close()
#         mydb.close()
#
#         # Check login success
#         if user:
#             # return HttpResponse(f"<b>Login successful! Welcome<b>,<br> {user[1]}.")
#             return render(request,'dashboard.html')
#
#
#         else:
#             return HttpResponse("Invalid email or password.<br>")
#
#     except mysql.connector.Error as err:
#         return HttpResponse(f"Database error: {err}")
#
#     except Exception as e:
#         return HttpResponse(f"An error occurred: {e}")


from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
import mysql.connector

def signin(request):
    return render(request, 'signin.html')

def login(request):
    email = request.GET.get("email")
    upass = request.GET.get("upass")

    if not email or not upass:
        messages.error(request, "Email and Password are required!")
        return redirect("signin")  # Redirect to the signin page

    try:
        # Connect to MySQL
        mydb = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="",
            database="projects"
        )
        cursor = mydb.cursor(buffered=True)

        # Query to check credentials
        query = "SELECT * FROM usermast WHERE email = %s AND upass = %s"
        values = (email, upass)
        cursor.execute(query, values)

        # Fetch the result
        user = cursor.fetchone()

        # Close the cursor and connection
        cursor.close()
        mydb.close()

        # Check login success
        if user:
            messages.success(request, f"Welcome, {user[1]}!")
            return render(request, 'dashboard.html')  # Redirect to dashboard
        else:
            messages.error(request, "Invalid email or password!")
            return redirect("signin")  # Redirect to signin page

    except mysql.connector.Error as err:
        messages.error(request, f"Database error: {err}")
        return redirect("signin")

    except Exception as e:
        messages.error(request, f"An error occurred: {e}")
        return redirect("signin")






def dashboard(request):
    return render(request, 'add-disease.html', {'disease': 'disease_name'})

from django.shortcuts import render
from django.http import HttpResponse
import mysql.connector

# def disease_info(request):
#     if request.method == "POST":
#         # Get form data using request.POST
#         disease_name = request.POST.get("disease_name")
#         s1 = request.POST.get("s1")
#         s2 = request.POST.get("s2")
#         s3 = request.POST.get("s3")
#         s4 = request.POST.get("s4")
#         medicine = request.POST.get("medicine")
#         age = request.POST.get("age")
#
#         # Check if any field is missing
#         if not all([disease_name, s1, s2, s3, s4, medicine, age]):
#             return HttpResponse("All fields are required.", status=400)
#
#         try:
#             # Connect to MySQL
#             mydb = mysql.connector.connect(
#                 host="127.0.0.1",
#                 user="root",
#                 password="",
#                 database="projects"
#             )
#             cursor = mydb.cursor()
#
#             # Query to insert data into disease_info table
#             query = """
#                 INSERT INTO disease_info (disease_name, s1, s2, s3, s4, medicine, age_group)
#                 VALUES (%s, %s, %s, %s, %s, %s, %s)
#             """
#             values = (disease_name, s1, s2, s3, s4, medicine, age)
#             cursor.execute(query, values)
#             mydb.commit()
#
#             # Close the cursor and connection
#             cursor.close()
#             mydb.close()
#
#             return HttpResponse("Disease information added successfully!")
#
#         except mysql.connector.Error as err:
#             return HttpResponse(f"Database error: {err}")
#         except Exception as e:
#             return HttpResponse(f"An error occurred: {e}")
#     else:
#         # Render the form if not a POST request
#         return render(request, 'add_disease.html')


from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
import mysql.connector

def disease_info(request):
    if request.method == "POST":
        # Get form data using request.POST
        disease_name = request.POST.get("disease_name")
        s1 = request.POST.get("s1")
        s2 = request.POST.get("s2")
        s3 = request.POST.get("s3")
        s4 = request.POST.get("s4")
        medicine = request.POST.get("medicine")
        age = request.POST.get("age")

        # Check if any field is missing
        if not all([disease_name, s1, s2, s3, s4, medicine, age]):
            messages.error(request, "All fields are required!")
            return redirect("disease_info")  # Redirect to form page

        try:
            # Connect to MySQL
            mydb = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="",
                database="projects"
            )
            cursor = mydb.cursor()

            # Query to insert data into disease_info table
            query = """
                INSERT INTO disease_info (disease_name, s1, s2, s3, s4, medicine, age_group)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            values = (disease_name, s1, s2, s3, s4, medicine, age)
            cursor.execute(query, values)
            mydb.commit()

            # Close the cursor and connection
            cursor.close()
            mydb.close()

            messages.success(request, "Disease information added successfully!")
            return redirect("disease_info")  # Redirect to form page

        except mysql.connector.Error as err:
            messages.error(request, f"Database error: {err}")
            return redirect("disease_info")

        except Exception as e:
            messages.error(request, f"An error occurred: {e}")
            return redirect("disease_info")

    else:
        # Render the form if not a POST request
        return render(request, 'add-disease.html')


# def disease_info(request):
#     if users():
#         return HttpResponse("Disease registered  successfully")






def disease_list(request):
    try:
        # Connect to MySQL
        mydb = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="",
            database="projects"
        )
        cursor = mydb.cursor()

        # Fetch all diseases
        query = "SELECT * FROM disease_info"
        cursor.execute(query)
        diseases = cursor.fetchall()

        # Close the connection
        cursor.close()
        mydb.close()

        # Render the disease list template
        return render(request, 'dashboard.html', {'diseases': diseases})

    except mysql.connector.Error as err:
        return HttpResponse(f"Database error: {err}")
    except Exception as e:
        return HttpResponse(f"An error occurred: {e}")




from django.shortcuts import render
from django.http import HttpResponse
import mysql.connector

def index(request):
    message = ""  # Default empty message

    if request.method == "POST":
        # Get form data from the request
        disease_name = request.POST.get("disease_name")
        symptom = request.POST.get("symptom")
        medicine = request.POST.get("medicine")
        age_min = request.POST.get("age_min")
        age_max = request.POST.get("age_max")

        # Check if all fields are filled
        if not all([disease_name, symptom, medicine, age_min, age_max]):
            message = "All fields are required!"
        else:
            try:
                # Connect to MySQL database
                mydb = mysql.connector.connect(
                    host="127.0.0.1",
                    user="root",
                    password="",
                    database="projects"
                )
                cursor = mydb.cursor()

                # Insert the data into the database
                query = """
                    INSERT INTO medicine_info (disease_name, symptom, medicine, age_min, age_max)
                    VALUES (%s, %s, %s, %s, %s)
                """
                values = (disease_name, symptom, medicine, age_min, age_max)
                cursor.execute(query, values)
                mydb.commit()

                # Close the cursor and connection
                cursor.close()
                mydb.close()

                message = "Disease information added successfully!"

            except mysql.connector.Error as err:
                message = f"Database error: {err}"
            except Exception as e:
                message = f"An error occurred: {e}"

    # Render the index page with the message
    return render(request, 'index.html', {"message": message})


from django.shortcuts import render
from django.db import connection

def user_list(request):
        try:
            # Connect to MySQL database
            mydb = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="",
                database="projects"
            )
            cursor = mydb.cursor()

            # Fetch user data
            cursor.execute("SELECT uid, uname, upass, email, mobile FROM usermast")
            users = cursor.fetchall()  # Get all records

            cursor.close()
            mydb.close()

            # Pass data to the template
            return render(request, 'show user.html', {'users': users})

        except mysql.connector.Error as err:
            return HttpResponse(f"Database error: {err}")
        except Exception as e:
            return HttpResponse(f"An error occurred: {e}")
