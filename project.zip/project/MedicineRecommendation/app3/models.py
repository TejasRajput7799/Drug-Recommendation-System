# from django.db import models
# from app3.models import Disease
#
# class Disease(models.Model):
#     disease_name = models.CharField(max_length=255)
#     s1 = models.CharField(max_length=255)
#     s2 = models.CharField(max_length=255)
#     s3 = models.CharField(max_length=255)
#     s4 = models.CharField(max_length=255)
#     medicine = models.CharField(max_length=255)
#     age_group = models.CharField(max_length=255)
#
#     class Meta:
#         db_table = 'disease_info'  # Match your XAMPP MySQL table name
#
#     def __str__(self):
#         return self.disease_name
# from django.apps import AppConfig
#
# class App3Config(AppConfig):
#     default_auto_field = 'django.db.models.BigAutoField'
#     name = 'app3'
# class Disease(models.Model):
#     name = models.CharField(max_length=100)
#
# class Treatment(models.Model):
#     disease = models.ForeignKey('app3.Disease', on_delete=models.CASCADE)
