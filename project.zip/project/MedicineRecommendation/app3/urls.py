from django.urls import path
from . import views
from .views import login

urlpatterns = [
    path('signin/', views.signin, name='signin'),
    path('login/', views.login, name='login'),
    path('login/searchSymptoms',views.searchSymptoms,name="search symptoms of the disease "),
    path('login/showMedicine', views.showMedicine, name='showMedicine'),
    path('submit_contact_form', views.submit_contact_form, name='submit_contact_form'),
    path('feedback', views.feedback, name='feedback'),  # Feedback form page
    path('submit_feedback', views.submit_feedback, name='submit_feedback'),  # Form submission handler



path('contact/', views.feedback, name='contact'),  # Ensure this URL exists
    path('submit_contact_form/', views.submit_contact_form, name='submit_contact_form'),

    path('signin/', views.signin, name='signin'),
    path('login/', views.login, name='login'),
    path('a/', views.A, name='A'),
]

