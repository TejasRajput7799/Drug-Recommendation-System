#
# def signin(request):
#     return render(request, 'signin.html')
#
#
# def login(request):
#     email = request.GET.get("email")
#     upass = request.GET.get("upass")
#
#     try:
#         # Connect to MySQL
#         mydb = mysql.connector.connect(
#             host="127.0.0.1",
#             user="root",
#             password="",
#             database="projects"
#         )
#         cursor = mydb.cursor(buffered=True)
#
#         # Query to check credentials
#         query = "SELECT * FROM usermast WHERE email = %s AND upass = %s"
#         values = (email, upass)
#         cursor.execute(query, values)
#
#         # Fetch the result
#         user = cursor.fetchone()
#
#         # Close the cursor and connection
#         cursor.close()
#         mydb.close()
#
#         # Check login success
#         if user:
#             # return HttpResponse(f"<b>Login successful! Welcome<b>,<br> {user[1]}.")
#             return render(request, 'a.html')
#
#         else:
#             return HttpResponse("Invalid email or password.<br>")
#
#
#     except mysql.connector.Error as err:
#         return HttpResponse(f"Database error: {err}")
#
#     except Exception as e:
#         return HttpResponse(f"An error occurred: {e}")
#
# def A(request):
#     return render(request,'a.html'),
#
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
import mysql.connector

def signin(request):
    return render(request, 'signin.html')

def login(request):
    email = request.GET.get("email")
    upass = request.GET.get("upass")

    if not email or not upass:
        messages.error(request, "Email and Password are required!")
        return redirect("signin")  # Redirect to the signin page

    try:
        # Connect to MySQL
        mydb = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="",
            database="projects"
        )
        cursor = mydb.cursor(buffered=True)

        # Query to check credentials
        query = "SELECT * FROM usermast WHERE email = %s AND upass = %s"
        values = (email, upass)
        cursor.execute(query, values)

        # Fetch the result
        user = cursor.fetchone()

        # Close the cursor and connection
        cursor.close()
        mydb.close()

        # Check login success
        if user:
            return render(request, 'a.html')  # Redirect to 'a.html' on success
        else:
            messages.error(request, "Invalid email or password!")
            return redirect("signin")  # Redirect to signin page

    except mysql.connector.Error as err:
        messages.error(request, f"Database error: {err}")
        return redirect("signin")

    except Exception as e:
        messages.error(request, f"An error occurred: {e}")
        return redirect("signin")

def A(request):
    return render(request, 'a.html')




def searchSymptoms(request):
    if request.method == "POST":
        disease = request.POST.get("disease", "").strip()
        if not disease:
            return render(request, "a.html", {"error": "Please provide a disease name."})

        try:
            # Connect to the database
            mydb = mysql.connector.connect(
                user="root",
                password="",
                host="localhost",
                database="projects",
            )
            
            mycur = mydb.cursor()

            # Check if disease exists
            mycur.execute("SELECT disease_name FROM disease_info WHERE disease_name=%s", (disease,))
            data = mycur.fetchone()

            if data:
                # Fetch symptoms
                mycur.execute("SELECT s1, s2, s3, s4 FROM disease_info WHERE disease_name=%s", (disease,))
                symptoms = mycur.fetchone()

                if symptoms:
                    symptoms_list = [symptom for symptom in symptoms if symptom]
                    return render(request, "a.html", {"symptoms": symptoms_list, "disease": disease})
                else:
                    return render(request, "a.html", {"error": "Symptoms not found for the specified disease."})
            else:
                return render(request, "a.html", {"error": "Disease not found in the database."})

        except Error as e:
            return render(request, "a.html", {"error": f"Database connection error: {str(e)}"})

    return render(request, "a.html", {"error": "Invalid request method. Please use POST."})






def showMedicine(request):
    if request.method == "POST":
        disease = request.POST.get("disease", "").strip()
        selected_symptoms = request.POST.getlist("selected_symptoms")
        age = request.POST.get("age", "").strip()

        if not disease or not selected_symptoms:
            return render(request, "a.html", {"error": "Please select symptoms to proceed."})

        if not age:
            # If age is not provided, ask the user for it
            return render(request, "a.html", {"symptoms": selected_symptoms, "disease": disease})

        try:
            age = int(age)
            # Connect to the database
            mydb = mysql.connector.connect(
                user="root",  # default user for XAMPP MySQL
                password="",  # default password is empty for XAMPP MySQL
                host="localhost",  # localhost for XAMPP
                database="projects",  # database name in XAMPP
            )
            mycur = mydb.cursor()

            # Dynamically create the placeholders for symptoms
            placeholders = ', '.join(['%s'] * len(selected_symptoms))

            # Query to fetch medicines based on symptoms and age group
            query = f"""
                SELECT DISTINCT medicine
                FROM medicine_info
                WHERE disease_name=%s
                AND symptom IN ({placeholders})
                AND (age_min <= %s AND age_max >= %s)
            """

            # Execute the query with parameters
            mycur.execute(query, [disease] + selected_symptoms + [age, age])
            medicines = mycur.fetchall()

            if medicines:
                medicine_list = [medicine[0] for medicine in medicines]
                return render(request, "a.html", {
                    "medicines": medicine_list,
                    "disease": disease,
                    "symptoms": selected_symptoms,
                })
            else:
                return render(request, "a.html", {"error": "No medicines found for the selected symptoms and age."})

        except Error as e:
            return render(request, "a.html", {"error": f"Database connection error: {str(e)}"})
        except ValueError:
            return render(request, "a.html", {"error": "Invalid age input. Please enter a valid number."})

    return render(request, "a.html", {"error": "Invalid request method. Please use POST."})





def submit_contact_form(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        message = request.POST.get("message")

        if not name or not email or not message:
            messages.error(request, "Error: All fields are required!")
            return redirect("contact")  # Redirect to the contact page

        try:
            # Connect to MySQL
            mydb = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="",
                database="projects"
            )
            cursor = mydb.cursor()

            # Insert form data into the database
            query = "INSERT INTO contact_form (name, email, message) VALUES (%s, %s, %s)"
            values = (name, email, message)
            cursor.execute(query, values)
            mydb.commit()

            cursor.close()
            mydb.close()

            messages.success(request, "Thank you! Your message has been submitted.")
            return redirect("/#contact")  # Redirect to the contact section

        except mysql.connector.Error as err:
            messages.error(request, f"Database error: {err}")
            # return redirect("contact")
            return redirect("/#contact")

        except Exception as e:
            messages.error(request, f"An error occurred: {e}")
            # return redirect("contact")
            return redirect("/#contact")

    else:
        return HttpResponse("Invalid request method.", status=405)



import mysql.connector
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
import mysql.connector

def feedback(request):
    return render(request, 'feedback.html')

# View to handle the form submission
def submit_feedback(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        feedback_text = request.POST.get('feedback')

        # Connect to MySQL to save feedback
        try:
            mydb = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="",
                database="projects"  # Replace with your actual database name
            )
            cursor = mydb.cursor()

            # Query to insert feedback into the database
            query = "INSERT INTO feedback (name, email, feedback, submitted_at) VALUES (%s, %s, %s, NOW())"
            values = (name, email, feedback_text)
            cursor.execute(query, values)

            # Commit the transaction and close the connection
            mydb.commit()
            cursor.close()
            mydb.close()

            # Add success message
            messages.success(request, "Thank you for your feedback!")

        except mysql.connector.Error as err:
            messages.error(request, f"Database error: {err}")

        except Exception as e:
            messages.error(request, f"An error occurred: {e}")

        # Redirect back to the feedback page
        return redirect('feedback')

    else:
        return HttpResponse("Invalid request method.", status=405)
