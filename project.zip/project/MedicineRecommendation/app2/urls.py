from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('signup/register/', views.register, name='register'),  # Include 'signup/register/' pattern
]