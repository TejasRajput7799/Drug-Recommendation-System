from django.shortcuts import render
from django.http import HttpResponse
import mysql.connector

from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
import mysql.connector

def signup(request):
    return render(request, 'signup.html')

def register(request):
    if request.method == "GET":
        # Get form data
        s1 = request.GET.get("uname")
        s2 = request.GET.get("upass")
        s3 = request.GET.get("email")
        s4 = request.GET.get("mobile")

        try:
            # Connect to MySQL
            mydb = mysql.connector.connect(
                host="127.0.0.1",  # Use localhost for XAMPP
                user="root",  # Default XAMPP user
                password="",  # Leave blank if no password
                database="projects"
            )

            cursor = mydb.cursor()

            # Insert query
            query = "INSERT INTO usermast (uname, upass, email, mobile) VALUES (%s, %s, %s, %s)"
            values = (s1, s2, s3, s4)
            cursor.execute(query, values)
            mydb.commit()

            # Close connection
            cursor.close()
            mydb.close()

            # Add success message
            messages.success(request, "Registration successful!")

        except mysql.connector.Error as err:
            messages.error(request, f"Database error: {err}")

        except Exception as e:
            messages.error(request, f"An error occurred: {e}")

        return redirect('signup')  # Redirect back to the signup page
